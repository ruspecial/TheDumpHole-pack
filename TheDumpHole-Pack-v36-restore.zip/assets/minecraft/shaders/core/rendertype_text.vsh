#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_e8783e1a(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_8c349002() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_a9c74357(inout vec4 vertex) {
    f_e8783e1a(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_8c349002();
    }
    finalize();
}



void f_bf594f7e() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_ea33f154() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_c524460f(inout vec4 vertex) {
    f_e8783e1a(vertex);
    f_bf594f7e();
    finalize();
}

void f_3fb84991(inout vec4 vertex) {
    f_e8783e1a(vertex);
    f_8c349002();
    f_ea33f154();
    finalize();
}

void f_9f93b3b7(inout vec4 vertex) {
    f_e8783e1a(vertex);
    f_ea33f154();
    f_bf594f7e();
    finalize();
}

void f_e5f9d758(inout vec4 vertex) {
    f_8c349002();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_e8783e1a(vertex);
    finalize();
}

void f_68ebfc20(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_bf594f7e();
    f_e8783e1a(vertex);
    finalize();
}

void f_955c1fb4(inout vec4 vertex, float speed) {
    f_e8783e1a(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_2af5b1fc(inout vec4 vertex) {
    f_e8783e1a(vertex);
    f_8c349002();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_a9c74357(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_8c349002();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_e8783e1a(vertex);
            f_8c349002();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_3fb84991(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_3fb84991(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_e5f9d758(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_e5f9d758(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_955c1fb4(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_2af5b1fc(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_c524460f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_3fb84991(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_9f93b3b7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_e5f9d758(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_68ebfc20(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_955c1fb4(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_c524460f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_3fb84991(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_9f93b3b7(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_e5f9d758(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_68ebfc20(vertex);
        return;
    }
    

    
    f_e8783e1a(vertex);
    f_8c349002();
    finalize();
}